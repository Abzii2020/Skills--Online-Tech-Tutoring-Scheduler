﻿<?php
    session_start();
    include_once 'dbconnect.php';

    if (!isset($_SESSION['userSession'])) {
	    header("Location: index.php");
    }

    $query = $DBcon->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
    $userRow=$query->fetch_array();
?>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <?php
         include "head.php";
    ?>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>
    <div id="wrapper">
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p class="pull-left hidden-xs">Timeless Education</p>
      
            <p class="pull-right"><i><a href="logout.php?logout"><strong>Logout</strong></a></i></p>
            <p class="pull-right"><i> <strong>Username: </strong><?php echo $userRow['username']; ?></i></p>
            <p class="pull-right"><i class=""><strong>Email: </strong><?php echo $userRow['email']; ?>&nbsp;&nbsp;</i></p>

          </div>
        </div>
      </div>
    </div>

    <header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="logo" /></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="dashboard.php">Dashboard</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header><!-- end header -->


</body>
</html>