﻿<?php
    session_start();
    include_once 'dbconnect.php';

    if(isset($_COOKIE['userSession']) && $_COOKIE['userSession'] != ''){

     $user = $_COOKIE['userSession'];
     //get user data from mysql

    }else if(isset($_SESSION['userSession']) && $_SESSION['userSession'] !=''){

     $user = $_SESSION['userSession'];
     //get user data from mysql
    }else{
     header("Location: index.php");
    }

    $query = $DBcon->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
    $userRow=$query->fetch_array();
    $DBcon->close();
?>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <?php
    include "head.php";
    ?>
</head>
<body>
    <div id="wrapper">
        <div class="topbar">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p class="pull-left hidden-xs">Timeless Education</p>
                        <p class="pull-right"><i><a href="logout.php?logout"><strong>Logout</strong></a></i></p>
                        <p class="pull-right"><i> <strong>Username: </strong><?php echo $userRow['username']; ?></i></p>
                        <p class="pull-right"><i class=""><strong>Email: </strong><?php echo $userRow['email']; ?>&nbsp;&nbsp;</i></p>

                    </div>
                </div>
            </div>
        </div>
        <!-- start header -->
        <header>
            <div class="navbar navbar-default navbar-static-top">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="logo" /></a>
                    </div>
                    <div class="navbar-collapse collapse ">
                        <ul class="nav navbar-nav">
                            <li><a href="dashboard.php">Dashboard</a></li>
                            <li><a href="appointment.php">Appointments</a></li>
                            <li class="active"><a href="about_login.php">About</a></li>
                            <li><a href="contact_login.php">Contact</a></li>
                            <li><a href="help_login.php">Help/Support</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header><!-- end header -->
        <section id="inner-headline">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="pageTitle"><i>About Us</i></h2>
                    </div>
                </div>
            </div>
        </section>
        <section id="content">
            <section class="section-padding">
                <div class="container">
                    <div class="row showcase-section">
                        <div class="col-md-6">
                            <img src="img/dev1.jpg" alt="showcase image">
                        </div>
                        <div class="col-md-6">
                            <div class="about-text">
                                <h3>What You Need To Know</h3>
                                <p>
                                    While many online platforms basically provide college-style classes,
                                    Courser is less formal and aimed more at improving creative skills.
                                    There are business and marketing classes on the platform, but the majority are courses in creative fields, taught by practicing experts within their specialization. The focus is on teaching practical skills that students can then use to create their own projects. Most courses involve a series of video lessons,
                                    combined with assignments for you to practice your skills.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="container">

                <div class="about">


                    <div class="row">
                        <div class="col-md-4">
                            <div class="block-heading-two">
                                <h3><span>Our Mission</span></h3>
                            </div>
                            <p>
                                To allow persons to understand, contribute to, and succeed in various categories of IT.
                                We will ensure to develop both the skills that a sound education provides and the competencies essential for success in the world of chemistry.
                            </p>
                            <p>We will also lead in generating practical and theoretical knowledge that enables chemistry students to better understand the chemistry world and improve the overall passing percentage for markets.</p>

                        </div>


                        <div class="col-md-4">
                            <div class="block-heading-two">
                                <h3><span>Our Vision</span></h3>
                            </div>
                            <p>
                                Our Vision is to provide Personlized Learning, Trusted Content, Tools to Empower Student.It encompasses aspiration, educational excellence, system leadership, social mobility and cohesion.
                            </p>
                            <p>
                                We aim to provide distance learning within a space created by the user, identify new methods of learning which targets understanding and rentention,provide a vast category of learning materials accessible any time.
                            </p>
                        </div>

                        <div class="col-md-4">
                            <div class="block-heading-two">
                                <h3><span>Why Choose Us?</span></h3>
                            </div>
                            <p>Our program replicates many of the best practices being used in other programs such as how to use data to effect change, emphasis on social justice, advocacy for school counseling, etc.  What we'll focus on here are the program’s unique elements. <br /><br />Motivation, Change, and nfluence strategies are presented in several of the classes.</p>
                        </div>

                    </div>



                    <br>
                    <!-- Our Team starts -->





                </div>

            </div>
        </section>
        <?php

        //Inlcudes footer within page
        include "footer.php";
        ?>
    </div>
    <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
    <!-- javascript
        ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/jquery.fancybox-media.js"></script>
    <script src="js/jquery.flexslider.js"></script>
    <script src="js/animate.js"></script>
    <!-- Vendor Scripts -->
    <script src="js/modernizr.custom.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/animate.js"></script>
    <script src="js/custom.js"></script>
</body>
</html>
