<?php
   // Array with names
   //$a[] = "Android";
   $a[] = "Abigail";
//   $a[] = "C programming language";
//   $a[] = "D programming language";
//   $a[] = "euphoria";
//   $a[] = "F#";
//   $a[] = "GWT";
   $a[] = "Venessa";
//   $a[] = "ibatis";
//   $a[] = "Java";
//   $a[] = "K programming language";
//   $a[] = "Lisp";
//   $a[] = "Microsoft technologies";
//   $a[] = "Networking";
//   $a[] = "Open Source";
   $a[] = "Monique";
//   $a[] = "QC";
//   $a[] = "Restful web services";
   $a[] = "Onaje";
   $a[] = "Tyshorna";
//   $a[] = "UML";
//   $a[] = "VB Script";
//   $a[] = "Web Technologies";
//   $a[] = "Xerox Technology";
//   $a[] = "YQL";
//   $a[] = "ZOPL";
   
   $q = $_REQUEST["q"];
   $hint = "";
   
   if ($q !== "") {
      $q = strtolower($q);
      $len = strlen($q);
      
      foreach($a as $name) {
		
         if (stristr($q, substr($name, 0, $len))) {
            if ($hint === "") {
               $hint = $name;
            }else {
               $hint .= ", $name";
            }
         }
      }
   }
   echo $hint === "" ? "Please enter a valid Tutor/Instructor" : $hint;
?>