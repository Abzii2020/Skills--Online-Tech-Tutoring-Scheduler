﻿<?php
    session_start();
    include_once 'dbconnect.php';

    if(isset($_COOKIE['userSession']) && $_COOKIE['userSession'] != ''){

     $user = $_COOKIE['userSession'];
     //get user data from mysql

    }else if(isset($_SESSION['userSession']) && $_SESSION['userSession'] !=''){

     $user = $_SESSION['userSession'];
     //get user data from mysql
    }else{
     header("Location: index.php");
    }

    $query = $DBcon->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
    $userRow=$query->fetch_array();
    $DBcon->close();
?>
<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <?php
    include "head.php";
    ?>
</head>
<body>
    <div id="wrapper">
        <div class="topbar">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p class="pull-left hidden-xs">Timeless Education</p>
                        <p class="pull-right"><i><a href="logout.php?logout"><strong>Logout</strong></a></i></p>
                        <p class="pull-right"><i> <strong>Username: </strong><?php echo $userRow['username']; ?></i></p>
                        <p class="pull-right"><i class=""><strong>Email: </strong><?php echo $userRow['email']; ?>&nbsp;&nbsp;</i></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- start header -->
        <header>
            <div class="navbar navbar-default navbar-static-top">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="logo" /></a>
                    </div>
                    <div class="navbar-collapse collapse ">
                        <ul class="nav navbar-nav">
                            <li><a href="dashboard.php">Dashboard</a></li>
                            <li><a href="appointment.php">Appointments</a></li>
                            <li><a href="about_login.php">About</a></li>
                            <li><a href="contact_login.php">Contact</a></li>
                            <li class="active"><a href="help_login.php">Help/Support</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header><!-- end header -->
        <section id="inner-headline">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="pageTitle"><i>Frequently Asked Questions</i></h2>
                    </div>
                </div>
            </div>
        </section>
        <section id="content">

            <div class="container">


                <div class="row">
                    <div class="col-md-12">
                        <div class="about-logo">
                            <h3><strong>How Can We Help You?</strong></h3>
                            <p>Search for Answers, Browse our Articles, or Submit a Question to our community of experts.</p>
                            <p>You can also browse the topics below to find what you are looking for</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                    </div>
                    <div class="col-lg-3">
                        <div class="pricing-box-item">
                            <div class="pricing-heading">
                                <h3><strong>General Information</strong></h3>
                            </div>
                            <div class="pricing-terms">
                                <p><a href="#">Getting Started FAQ</a></p>
                            </div>
                            <div class="pricing-container">
                                <ul>
                                    <li><i class="icon-ok"></i> <a href="index.php">How to Register</a></li>
                                    <li><i class="icon-ok"></i> <a href="index.php">Enrolling in Courses</a></li>
                                    <li><i class="icon-ok"></i> <a href="index.php">Accessing Online Materials</a></li>
                                </ul>
                            </div>
                            <div class="pricing-action">
                                <a href="contact.php" class="btn btn-medium"><i class="icon-bolt"></i> Direct Support</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="pricing-box-item activeItem">
                            <div class="pricing-heading">
                                <h3><strong>Network<br>Security</strong></h3>
                            </div>
                            <div class="pricing-terms">
                                <p><a href="#">Getting Started FAQ</a></p>
                            </div>
                            <div class="pricing-container">
                                <ul>
                                    <li><i class="icon-ok"></i><a href="index.php"> Cloud Security</a></li>
                                    <li><i class="icon-ok"></i><a href="index.php"> Security Software</a></li>
                                    <li><i class="icon-ok"></i><a href="index.php"> Secure Firewall</a></li>

                                </ul>
                            </div>
                            <div class="pricing-action">
                                <a href="contact.php" class="btn btn-medium"><i class="icon-bolt"></i> Direct Support</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="pricing-box-item">
                            <div class="pricing-heading">
                                <h3><strong>Data<br>Management</strong></h3>
                            </div>
                            <div class="pricing-terms">
                                <p><a href="#">Getting Started FAQ</a></p>
                            </div>
                            <div class="pricing-container">
                                <ul>
                                    <li><i class="icon-ok"></i><a href="index.php"> Information Systems</a></li>
                                    <li><i class="icon-ok"></i><a href="index.php"> Data Analysis</a></li>
                                    <li><i class="icon-ok"></i><a href="index.php"> Data Engineering</a></li>
                                </ul>
                            </div>
                            <div class="pricing-action">
                                <a href="contact.php" class="btn btn-medium"><i class="icon-bolt"></i> Direct Support</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="pricing-box-item">
                            <div class="pricing-heading">
                                <h3><strong>Application Development</strong></h3>
                            </div>
                            <div class="pricing-terms">
                                <p><a href="#">Getting Started FAQ</a></p>
                            </div>
                            <div class="pricing-container">
                                <ul>
                                    <li><i class="icon-ok"></i><a href="index.php"> Mobile Application</a></li>
                                    <li><i class="icon-ok"></i><a href="index.php"> Desktop Application</a></li>
                                    <li><i class="icon-ok"></i><a href="index.php"> Web Application</a></li>
                                </ul>
                            </div>
                            <div class="pricing-action">
                                <a href="contact.php" class="btn btn-medium"><i class="icon-bolt"></i> Direct Support</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php
        //Inlcudes footer within page
        include "footer.php";
        ?>

    </div>
    <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
    <!-- javascript
        ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/jquery.fancybox-media.js"></script>
    <script src="js/jquery.flexslider.js"></script>
    <script src="js/animate.js"></script>
    <!-- Vendor Scripts -->
    <script src="js/modernizr.custom.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/animate.js"></script>
    <script src="js/custom.js"></script>

    <script src="contact/jqBootstrapValidation.js"></script>
    <script src="contact/contact_me.js"></script>
</body>
</html>


