﻿<?php
session_start();
include_once 'dbconnect.php';

if(isset($_COOKIE['userSession']) && $_COOKIE['userSession'] != ''){
 
 $user = $_COOKIE['userSession'];
 //get user data from mysql

}else if(isset($_SESSION['userSession']) && $_SESSION['userSession'] !=''){
 
 $user = $_SESSION['userSession'];
 //get user data from mysql
}else{
 header("Location: index.php");
}

//if (!isset($_SESSION['userSession'])) {
//	header("Location: index.php");
//}

$query = $DBcon->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();

$sql="SELECT username,email, Empname, Empemail, date, time, specifications FROM tbl_appointments ORDER BY username";

if ($result=mysqli_query($DBcon,$sql))
  {
  // Return the number of rows in result set
  $rowcount=mysqli_num_rows($result);
  $count = $rowcount;
  // Free result set
  mysqli_free_result($result);
  }

$userlevel= 3;

$sql="SELECT username,email,gender,location,userlevel FROM tbl_users WHERE userlevel='$userlevel'";

if ($result=mysqli_query($DBcon,$sql))
  {
  // Return the number of rows in result set
  $rowcount=mysqli_num_rows($result);
  $count1 = $rowcount;
  // Free result set
  mysqli_free_result($result);
  }

$level= 2;

$sql="SELECT username,email,gender,location,userlevel FROM tbl_users WHERE userlevel='$level'";

if ($result=mysqli_query($DBcon,$sql))
  {
  // Return the number of rows in result set
  $rowcount=mysqli_num_rows($result);
  $count2 = $rowcount;
  // Free result set
  mysqli_free_result($result);
  }


$DBcon->close();

?>
<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <?php
    include "head.php";
    ?>
</head>
<body>
    <div id="wrapper">
        <div class="topbar">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p class="pull-left hidden-xs">Timeless Education</p>

                        <p class="pull-right"><i><a href="logout.php?logout"><strong>Logout</strong></a></i></p>
                        <p class="pull-right"><i> <strong>Username: </strong><?php echo $userRow['username']; ?></i></p>
                        <p class="pull-right"><i class=""><strong>Email: </strong><?php echo $userRow['email']; ?>&nbsp;&nbsp;</i></p>

                    </div>
                </div>
            </div>
        </div>

        <header>
            <div class="navbar navbar-default navbar-static-top">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="logo" /></a>
                    </div>
                    <div class="navbar-collapse collapse ">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="dashboard.php">Dashboard</a></li>
                            <li><a href="tutor.php">Tutors</a></li>
                            <li><a href="student_info.php">Students</a></li>
                            <li><a href="logs.php">Logs</a></li>
                            <li><a href="reports.php">Reports</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header><!-- end header -->
        <section id="inner-headline">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="pageTitle"><i></i></h2>
                    </div>
                </div>
            </div>
        </section>


        <br>
        <div class="container">
            <div class="row">
                <div class="col-md-10">
                    <h1><span aria-hidden="true"></span>Dashboard <small>Admin</small></h1>
                </div>
                <div class="col-md-2">
                    <div class="dropdown create">
                      <button class="btn btn-default dropdown-toggle" class"pull-right" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        Views
                        <span class="caret"></span>
                      </button>
                      <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <li><a href="newInstructors.php">Upcoming Instructors</a></li>
                      </ul>
                    </div>
                </div>
            </div>  
        </div>

        <!--Main Section-->
      <section id="main">
      <div class="container">
      <div class="row">
          <div class="col-md-3">
          <!--Side bar-->
              <div class="list-group">
                  <a href="dashboard.php" class="list-group-item active main-color-bg">
                    Dashboard
                  </a>
                  <a href="report.php" class="list-group-item"><span aria-hidden="true"></span>Reports<span class="badge"><?php
                                if (isset($count)) {
                                    echo $count;
                                }
                            ?></span></a>

                  <a href="logs.php" class="list-group-item"><span aria-hidden="true"></span>Logs <span class="badge"><?php
                                if (isset($count)) {
                                    echo $count;
                                }
                            ?></span></a>
                  <a href="student_info.php" class="list-group-item"><span aria-hidden="true"></span>Students  <span class="badge"><?php
                                if (isset($count1)) {
                                    echo $count1;
                                }
                            ?></span></a>
                  <a href="tutor.php" class="list-group-item"><span aria-hidden="true"></span>Instructors/Tutors<span class="badge"><?php
                                if (isset($count2)) {
                                    echo $count2;
                                }
                            ?></span></a>
                  
            </div>
              
             <!-- <div class="well">
                  <h4>Disk Space Used</h4>
                  <div class="progress">
                      <div class="progress-bar main-color-bg" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
                        60%
                      </div>
                  </div>

                <h4>Bandwidth Used</h4>
                  <div class="progress">
                      <div class="progress-bar main-color-bg" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 40%;">
                        40%
                      </div>
                  </div>    
              </div>-->
              
          </div>
          
          <div class="col-md-9">
              <div class="panel panel-default">
                  <div class="panel-heading main-color-bg">
                    <h3 class="panel-title">Website Overview</h3>
                  </div>
                  <div class="panel-body">
                    <div class="col-md-3">
                        <div class="well dash-box">
                            <h2><span aria-hidden="true"></span><?php
                                if (isset($count)) {
                                    echo $count;
                                }
                            ?></h2>
                            <h4> Logs</h4>
                        </div>  
                    </div>
                      
                      
                      <div class="col-md-3">
                        <div class="well dash-box">
                            <h2><span aria-hidden="true"></span><?php
                                if (isset($count1)) {
                                    echo $count1;
                                }
                            ?></h2>
                            <h4> Students</h4>
                        </div>  
                    </div>
                      
                      <div class="col-md-3">
                        <div class="well dash-box">
                            <h2><span aria-hidden="true"></span><?php
                                if (isset($count2)) {
                                    echo $count2;
                                }
                            ?></h2>
                            <h4> Tutors</h4>
                        </div>  
                    </div>
                  </div>
          </div>
          
             <?php
    
                include 'dbconnect.php';

                $emp = 2;

            //    $sql = "SELECT username, email, gender, location, photo FROM tbl_users WHERE userlevel='$emp'";
               // $image=addslashes(@file_get_contents($_FILES['pic']['tmp_name']));
                $result = $DBcon->query("SELECT username, email, gender, location FROM tbl_users WHERE userlevel='$emp'");

                if ($result->num_rows > 0) {
                    // output data of each row
                    echo "<div class='panel panel-default'>
                          <div class='panel-heading'>
                            <h3 class='panel-title'>Instructors/Tutors</h3>
                          </div>
                          <div class='panel-body'>";
                    echo "<table class='table table-striped table-hover'>";
                    echo "<tr> <th>Username</th> <th>Email</th> <th>Gender</th> <th>Location</th> </tr> ";
                    while($row = mysqli_fetch_array($result)) {
                        //echo "<tr> <th>Email</th> <th>Gender</th> <th>Username</th> <th>Location</th> </tr> ";
                        echo "<tr><td>". $row["username"]. "</td><td>" . $row["email"]. "</td><td>" . $row["gender"]. "</td><td>" . $row["location"]. "<br>" ;
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }

            ?>
              
             <?php
    
                include 'dbconnect.php';

                $emp = 3;

            //    $sql = "SELECT username, email, gender, location, photo FROM tbl_users WHERE userlevel='$emp'";
               // $image=addslashes(@file_get_contents($_FILES['pic']['tmp_name']));
                $result = $DBcon->query("SELECT username, email, gender, location FROM tbl_users WHERE userlevel='$emp'");

                if ($result->num_rows > 0) {
                    // output data of each row
                    echo "<div class='panel panel-default'>
                          <div class='panel-heading'>
                            <h3 class='panel-title'>Students</h3>
                          </div>
                          <div class='panel-body'>";
                    echo "<table class='table table-striped table-hover'>";
                    echo "<tr> <th>Username</th> <th>Email</th> <th>Gender</th> <th>Location</th> </tr> ";
                    while($row = mysqli_fetch_array($result)) {
                        //echo "<tr> <th>Email</th> <th>Gender</th> <th>Username</th> <th>Location</th> </tr> ";
                        echo "<tr><td>". $row["username"]. "</td><td>" . $row["email"]. "</td><td>" . $row["gender"]. "</td><td>" . $row["location"]. "<br>" ;
                    }
                    echo "</table>";
                } else {
                    echo "0 results";
                }

            ?>
              
          </div>
      </div>    
      </div>
      </section>>

       

        <?php

        //Inlcudes footer within page
        include "footer.php";
        ?>
    </div>
    <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
    <!-- javascript
        ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/jquery.fancybox-media.js"></script>
    <script src="js/jquery.flexslider.js"></script>
    <script src="js/animate.js"></script>
    <!-- Vendor Scripts -->
    <script src="js/modernizr.custom.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/animate.js"></script>
    <script src="js/custom.js"></script>
</body>
</html>

