﻿<?php
    session_start();
    include_once 'dbconnect.php';

    if(isset($_COOKIE['userSession']) && $_COOKIE['userSession'] != ''){

     $user = $_COOKIE['userSession'];
     //get user data from mysql

    }else if(isset($_SESSION['userSession']) && $_SESSION['userSession'] !=''){

     $user = $_SESSION['userSession'];
     //get user data from mysql
    }else{
     header("Location: index.php");
    }

    $query = $DBcon->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
    $userRow=$query->fetch_array();
    $DBcon->close();
?>



<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <?php
         include "head.php";
    ?>
    <meta charset="utf-8" />
    <title>Welcome - <?php echo $userRow['username']; ?></title>
</head>
<body>

    <div id="wrapper">
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p class="pull-left hidden-xs">Timeless Education</p>
      
            <p class="pull-right"><i><a href="logout.php?logout"><strong>Logout</strong></a></i></p>
            <p class="pull-right"><i> <strong>Username: </strong><?php echo $userRow['username']; ?></i></p>
            <p class="pull-right"><i class=""><strong>Email: </strong><?php echo $userRow['email']; ?>&nbsp;&nbsp;</i></p>

          </div>
        </div>
      </div>
    </div>

     <header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="logo" /></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="dashboard.php">Dashboard</a></li>
                        <li><a href="appointment.php">Appointments</a></li>
                        <li><a href="about_login.php">About</a></li>
                        <li><a href="contact_login.php">Contact</a></li>
                        <li><a href="help_login.php">Help/Support</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header><!-- end header -->

    <section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle"><i>Dashboard</i></h2>
			</div>
		</div>
	</div>
	</section>

    <section id="content">

        <div class="container">
               

                <div class="row"> 
					<div class="col-md-12">
						<div class="about-logo">
							<!--<h3><strong>How Can We Help You?</strong></h3>-->
							<p>Ready to set your next appointment with us?</p>
							<p>That's great! Give us a call, check out our appointments page or send us an email and we will get back to you as soon as possible!</p>
						</div>  
				    </div>
				</div>

                <div class="row">
					<div class="col-lg-12"> 
				</div>
				<div class="col-lg-3">
					<div class="pricing-box-item">
						<div class="pricing-heading">
							<h3><strong>Mobile App Development</strong></h3>
						</div>
					<div class="pricing-terms">
						<h6>&#36;2500/Session</h6>
					</div>
					<div class="pricing-container">
						<ul>
							<li><i class="icon-ok"></i>Getting Started</li>
							<li><i class="icon-ok"></i>Platforms</li>
							<li><i class="icon-ok"></i>Languages</li>
							<li><i class="icon-ok"></i>Assignments</li>
							<li><i class="icon-ok"></i>Worksheets</li>
							<li><i class="icon-ok"></i>Tutorials</li>						
						</ul>
					</div>
					<div class="pricing-action">
						<a href="appointment.php" class="btn btn-medium"><i class="icon-bolt"></i> Schedule Session</a>
					</div>
				</div>
			</div>
			
			<div class="col-lg-3">
				<div class="pricing-box-item activeItem">
					<div class="pricing-heading">
						<h3><strong>Network<br>Security</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>&#36;3500/Session</h6>
					</div>
					<div class="pricing-container">
						<ul>
							<li><i class="icon-ok"></i>Getting Started</li>
							<li><i class="icon-ok"></i>Platforms</li>
							<li><i class="icon-ok"></i>Languages</li>
							<li><i class="icon-ok"></i>Assignments</li>
							<li><i class="icon-ok"></i>Worksheets</li>
							<li><i class="icon-ok"></i>Tutorials</li>
						</ul>
					</div>
					<div class="pricing-action">
						<a href="appointment.php" class="btn btn-medium"><i class="icon-bolt"></i> Schedule Session</a>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="pricing-box-item">
					<div class="pricing-heading">
						<h3><strong>Data<br>Management</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>&#36;1500/Session</h6>
					</div>
					<div class="pricing-container">
						<ul>
							<li><i class="icon-ok"></i>Getting Started</li>
							<li><i class="icon-ok"></i>Platforms</li>
							<li><i class="icon-ok"></i>Languages</li>
							<li><i class="icon-ok"></i>Assignments</li>
							<li><i class="icon-ok"></i>Worksheets</li>
							<li><i class="icon-ok"></i>Tutorials</li>
						</ul>
					</div>
					<div class="pricing-action">
						<a href="appointment.php" class="btn btn-medium"><i class="icon-bolt"></i> Schedule Session</a>
					</div>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="pricing-box-item">
					<div class="pricing-heading">
						<h3><strong>Desktop App Development</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>&#36;1500/Session</h6>
					</div>

					<div class="pricing-container">
						<ul>
							<li><i class="icon-ok"></i>Getting Started</li>
							<li><i class="icon-ok"></i>Platforms</li>
							<li><i class="icon-ok"></i>Languages</li>
							<li><i class="icon-ok"></i>Assignments</li>
							<li><i class="icon-ok"></i>Worksheets</li>
							<li><i class="icon-ok"></i>Tutorials</li>


						</ul>
					</div>
					<div class="pricing-action">
						<a href="appointment.php" class="btn btn-medium"><i class="icon-bolt"></i> Schedule Session</a>
					</div>
				</div>
			</div>
		</div>
        </div>
</section>
		<div class="jumbotron text-center">
		  <h1>Skills</h1> 
		  
		  <p>Subscribe to get daily updates</p> 
		  <form method="post" action="">
			<div class="input-group">
			  <input type="email" name="email" class="form-control" size="50" placeholder="Email Address" required>
			  <div class="input-group-btn">
				<button type="submit" name="subscribe" class="btn btn-danger">Subscribe</button>
			  </div>
			</div>
		  </form>
				<a href="QR.php"><h3>GET ACCESS TO EXTERNAL RESOURCES<h3></a>
		</div>

    <?php
         include "footer.php";
    ?>
</div>
<!--<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>-->
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script> 
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<!-- Vendor Scripts -->
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
</body>
</html>